import { defineAppConfig } from "@agent-native/core/server";

export default defineAppConfig({
  app: {
    // This name appears in transactional emails. Change it to your product name.
    name: "Transer",
    // The source template keeps a renamed app from inheriting first-party email branding.
    sourceTemplate: "builder-code-starter",
    // Keep the template's authenticated entry explicit after renaming the app.
    homePath: "/",
    // Optional: use your own absolute HTTPS logo URL in transactional emails.
    // logoUrl: "https://example.com/logo.png",
  },
});
